﻿using System; //1d77454c-bc85-4fc6-b63f-d97bedb09b8b
using UnityEngine;

namespace $rootnamespace$
{
    [AddComponentMenu("$rootnamespace$/$rootnamespace$.$safeitemname$")]
    internal class $safeitemname$ : MonoBehaviour 
    {

    }
}
