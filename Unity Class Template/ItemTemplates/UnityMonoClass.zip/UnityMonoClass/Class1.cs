﻿using System;
using UnityEngine;

namespace $rootnamespace$
{
    [AddComponentMenu("$rootnamespace$/$rootnamespace$.$safeitemname$")]
    internal class $safeitemname$ : MonoBehaviour 
    {

    }
}
